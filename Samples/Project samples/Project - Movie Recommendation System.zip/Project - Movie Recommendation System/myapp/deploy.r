library(rsconnect)

rsconnect::setAccountInfo(name='harshdarji',
                          token='98AAEBAE8BC4F8FEDD8FAAB4794B5160',
                          secret='6TWgIFeioyqtJyzTCidY+KcTOcraIQcR+16ENDER')

library(rsconnect)
rsconnect::deployApp('C://Users//Harsh Darji//Documents//myapp')

library


rsconnect::setAccountInfo(name='harshdarji',
                          token='98AAEBAE8BC4F8FEDD8FAAB4794B5160',
                          secret='6TWgIFeioyqtJyzTCidY+KcTOcraIQcR+16ENDER')

