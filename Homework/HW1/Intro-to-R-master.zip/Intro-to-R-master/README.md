# Intro-to-R
Introduction to Using R and areas where it Shines.

I've included a lot of the basic syntax up front so a person reasonably familiar with programming in another lanugage can look through this and pick up basic usage quickly.  

Moving on are a coupld of advanced areas including discussions of matrix operations, a couple basic statiscial operations, and plotting using GGPlot2.

I hope everyone enjoys.
